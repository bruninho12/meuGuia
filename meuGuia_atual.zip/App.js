// Entrypoint gerenciado pelo `expo-router`
import "expo-router/entry";
