declare module "firebase/auth/react-native" {
  // Declaração mínima para satisfazer o TypeScript enquanto não há tipos oficiais
  export function getReactNativePersistence(storage: any): any;
}
